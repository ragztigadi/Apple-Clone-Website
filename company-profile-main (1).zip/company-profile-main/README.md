## 🍎— Responsive Apple Website Clone using only HTML & CSS - Progate New Year Bootcamp 2021 Team project.
![](Readme/client-side.JPG)
Apple Website Clone using only HTML & CSS - Progate New year 2021 Bootcamp Project Team.
Progate New Year Bootcamp 2021 Team project. We managed to finish the project in 3 days, i'm satisfied to see all of the members doing their job really well

### To be declared "PASS", your Webpage must have 6 of this components:

- Header ✔
- Bagian Main ✔
- Bagian Body ✔
- Footer ✔
- Setidaknya satu animasi ✔
- Desain responsif untuk smartphone dan tablet ✔

finished in 3 days.
